<?php

$value = 23; //call and set variables here from the Mysqli commands
//from the database
// so set price varibles for each glass here.... using separate sql statements

//echo the html sections in which this will exist and the javascript tags
echo "<html><body> <h1>Hello All</h1><script type='text/javascript'>";
//Call the js functions here using the same method he has and run the same js scripts but with php variables
//change img variables into php variables to make them work maybe?
//in the js set a php variable that i can use to ID the if statement and serve as a conditional

$value = $value + 23;
//echo the function with php vars instead of js vars.
echo "var a = $value; document.writeln(a + 5);";

echo "</script></body></html>";


?>