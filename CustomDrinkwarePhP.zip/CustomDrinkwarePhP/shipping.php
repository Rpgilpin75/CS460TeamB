<html>
<head>
	<meta charset="utf-8">
	<title>Custom Drinkware</title>
	<link href="images/avatar.png" rel="shortcut icon" type="image/png">
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<script src="js/glassbuttons.js" type="text/javascript"></script>
	<script src="js/bottleopeners.js" type="text/javascript"></script>
	<script src="js/barbuttons.js" type="text/javascript"></script>
	<script src="js/customize.js" type="text/javascript"></script>
	<style type="text/css">
	fieldset {
	margin: .1in 0in .1in .25in;
	float: left;
	border-radius: 12px;
}
	input, select {
	display: block;
}
	input[type=text] {
	width: 170px;
}
	input[type=button], input[type=reset] {
	display: block;
	clear: left;
	width: .75in;
	margin: .05in;
}
	#out {
	text-align: center;
}
	#out span {
	display: block;
	font-size: 18pt;
	width: 600px;
}
	hr {
	clear: left;

}	
</style>

	<script type="text/javascript">
	//var tprice=sessionStorage.getItem('total');
	//alert(sessionStorage.getItem('total'));
	//alert(document.getElementById('total').value = tprice;);
	
	</script>
	
</head>

<body>
	<header>
	</header>
	<nav>
			<ul>		
			<li><a href="Glassware.php">Glassware</a></li>
			<li><a href="BottleOpeners.php">Bottle Openers</a></li>
			<li><a href="BarSupplies.php">Bar Supplies</a></li>
			<li><a href="userprofile.php">Profile</a></li>
			<li><a href="logout.php">Logout</a></li>

								</ul>
	</nav>
	<aside>
	<!-- for when php does not show up for some reason
	<a href="registerPHP.php">PHP</a> -->
	</aside>
	<section>
		<?php 
session_start();   //check login
$tprice = test_input($_POST["price"]);
$prodname = test_input($_POST["prod"]);
$customname = test_input($_POST["custom"]);
//testing passed js variables
/*echo($tprice);
echo($prodname);
echo($customname);*/

//Product Session Variable
$_SESSION['productname']=$prodname;
$_SESSION['totalprice']=$tprice;
$_SESSION['customname']=$customname;

//testing sessions
/*echo($_SESSION['productname']);
echo($_SESSION['totalprice']);
echo($_SESSION['customname']);*/

function test_input($data){
     $data = trim($data);
     $data = stripslashes($data);
     $data = htmlspecialchars($data);
     return $data;
}


	//write to browser
echo "<link href='css/page.css' rel='stylesheet' type='text/css'/>";
echo '
<fieldset>
<h1>Shipping Information</h1>
<form action="shippingPHP.php" method="post">
<table>
<tr><td>Recipient Name</td><td><input type="text" name="recname" required></td></tr><br/>
<tr><td>Shipping Address</td><td> <input type="text" name="shipaddress" required></td></tr><br/>
<tr><td>City </td><td><input type="text" name="shipcity" required></td></tr></br>
<tr><td>State</td><td><input type="text" name="shipstate" required></td></tr><br/>
<tr><td>Zip </td><td><input type="text" name="shipzip" required></td></tr><br/>
<tr><td>Recipient Phone Number</td><td> <input type="text" name="recphone"></td></tr></br>
<tr><td colspan="2"><input type="submit" value="Continue"/></td></tr>
</table>
</form>
</fieldset>
';

?>
	</section>
	<footer>
	</footer>
</body>
</html>