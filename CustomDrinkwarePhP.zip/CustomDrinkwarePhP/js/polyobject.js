﻿/* polyobject.js -----------------------------------------------------
    Polygon object
    CS402-001 Spring 2015
    3/31/2015
--------------------------------------------------------------------*/           
    function Polygon(varray) {
        if(!varray) {
            varray = [];
        }
/* instance variables ------------------------------------------------
    initializes vertices from varray
--------------------------------------------------------------------*/  
        this.vertices = new Array();
        this.xl = 1000;
        this.yt = 1000;
        this.xr = -1;
        this.yb = -1;
        this.setVertices = function(){
            for (var i = 0; i < varray.length;i++) {
                this.vertices[i] = varray[i];
            }
        }  
        this.setVertices();
               
/* boundingbox -------------------------------------------------------
    finds min and max of vertices x and y
    initializes instance variable xl, yt, xr, yb
--------------------------------------------------------------------*/           
        this.boundingbox = function() {
            var minx = 1000;
            var miny = 1000;
            var maxx = -1;
            var maxy = -1;
            for (var i = 0; i < this.vertices.length; i+=2) {
                if(this.vertices[i] < minx) minx = this.vertices[i];
                if(this.vertices[i] > maxx) maxx = this.vertices[i];
                if(this.vertices[i+1] < miny) miny = this.vertices[i+1];
                if(this.vertices[i+1] > maxy) maxy = this.vertices[i+1];
            }
            this.xl = minx;        // left of bounding box
            this.yt = miny;        // top of bounding box
            this.xr = maxx;        // right of bounding box
            this.yb = maxy;        // bottom of bounding box
        }
        this.boundingbox();
           
/* stroke ------------------------------------------------------------
    draws and strokes polygon
    c is context
    ss is strokeStyle
--------------------------------------------------------------------*/    
        this.stroke = function(c,ss) {
            c.beginPath();
            var x = this.vertices[0];
            var y = this.vertices[1];
            c.moveTo(x,y);
            for (var i = 2; i < this.vertices.length; i+=2) {
                x = this.vertices[i];
                y = this.vertices[i+1];
                c.lineTo(x,y);
            }
            c.closePath();
            c.strokeStyle = ss;    
            c.stroke();
        }
           
/* fill --------------------------------------------------------------
    draws and fills polygon
    c is context
    fs is fillStyle
--------------------------------------------------------------------*/               
        this.fill = function(c,fs) {
           c.beginPath();
           var x = this.vertices[0];
           var y = this.vertices[1];
           c.moveTo(x,y);
           for (var i = 2; i < this.vertices.length; i+=2) {
               x = this.vertices[i];
               y = this.vertices[i+1];
               c.lineTo(x,y);
           }
           c.closePath();
           c.fillStyle = fs;
           c.fill();
       }

/* normalize ---------------------------------------------------------
    computes vertices so that painted polygon 
    is in upperleft corner of canvas
--------------------------------------------------------------------*/           
        this.normalize = function() {
            this.boundingbox();
            for (var i = 0; i < this.vertices.length; i+=2) {
                this.vertices[i] -= this.xl;
                this.vertices[i+1] -= this.yt;
            }
            this.xr -= this.xl;
            this.yb -= this.yt;
            this.xl = 0;
            this.yt = 0;
        }
        
/* translate ---------------------------------------------------------
    x' = x + dx
    y' = y + dy
--------------------------------------------------------------------*/           
        this.translate = function(dx,dy) {
            for (var i = 0; i < this.vertices.length; i+=2) {
                this.vertices[i] += dx;
                this.vertices[i+1] += dy;
            }
            this.boundingbox();
        }
           
/* center ------------------------------------------------------------
    Polygon bounding box will be centered around (cx,cy) 
--------------------------------------------------------------------*/           
        this.center = function(cx,cy) {
            this.normalize();
            var dx = Math.round(cx - this.xr / 2);
            var dy = Math.round(cy - this.yb / 2);
            this.translate(dx,dy);
        }
         
/* save --------------------------------------------------------------
    saves this polygon in another Polygon p 
    p <= this
--------------------------------------------------------------------*/           
        this.save = function(p) {
            p.xl = this.xl;
            p.yt = this.yt;
            p.xr = this.xr;
            p.yb = this.yb;
            for (var i = 0; i < this.vertices.length; i++) {
                p.vertices[i] = this.vertices[i];
            }
        }
           
/* restore -----------------------------------------------------------
    restores this polygon from another Polygon p 
    this <- p
--------------------------------------------------------------------*/           
        this.restore = function(p) {
            this.xl = p.xl;
            this.yt = p.yt;
            this.xr = p.xr;
            this.yb = p.yb;
            for (var i = 0; i < p.vertices.length; i++) {
                this.vertices[i] = p.vertices[i];
            }
        }
                     
/* dump --------------------------------------------------------------
    places polygon info into div tag with id = x
--------------------------------------------------------------------*/           
        this.dump = function(dump) {
            var html = "";
            html += "xl:"+Math.round(this.xl)+"&nbsp;";
            html += "yt:"+Math.round(this.yt)+"&nbsp;";
            html += "xr:"+Math.round(this.xr)+"&nbsp;";
            html += "yb:"+Math.round(this.yb)+"<br>";
            html += "<hr> = [";
            for (var i = 0; i < this.vertices.length-1; i++) {
                html += Math.round(this.vertices[i]) + ",";
                if(i % 8 == 7) html += "<br>";
            }
            html += Math.round(this.vertices[this.vertices.length-1]) + "];";
            document.getElementById(dump).innerHTML = html;
        }
                     
/* dumpspecial --------------------------------------------------------------
    places polygon info into div tag with id = x
--------------------------------------------------------------------*/           
        this.dumpspecial = function(dump,text,a,b,e,c,d,f) {
            var html = "";
            html += "<span class='titl'>"+text+"</span><hr>";
            if(!a) {
            html += "<span class='matrix lborder'>"+"&nbsp;a"+"</span>";
            html += "<span class='matrix'>"+"&nbsp;b"+"</span>";
            html += "<span class='matrix rborder'>"+0+"</span><br>";
            html += "<span class='matrix lborder'>"+"&nbsp;c"+"</span>";
            html += "<span class='matrix'>"+"&nbsp;d"+"</span>";
            html += "<span class='matrix rborder'>"+0+"</span><br>";
            html += "<span class='matrix lborder'>"+"&nbsp;e"+"</span>";
            html += "<span class='matrix'>"+"&nbsp;f"+"</span>";
            html += "<span class='matrix rborder'>"+1+"</span><br>";
            html += "<hr>";
            }
            else {
            html += "<span class='matrix lborder'>"+a+"</span>";
            html += "<span class='matrix'>"+b+"</span>";
            html += "<span class='matrix rborder'>"+0+"</span><br>";
            html += "<span class='matrix lborder'>"+c+"</span>";
            html += "<span class='matrix'>"+d+"</span>";
            html += "<span class='matrix rborder'>"+0+"</span><br>";
            html += "<span class='matrix lborder'>"+e+"</span>";
            html += "<span class='matrix'>"+f+"</span>";
            html += "<span class='matrix rborder'>"+1+"</span><br>";
            html += "<hr>";
            }
            for (var i = 0; i < this.vertices.length; i+=2) {
                html += "<span class='matrix lborder'>"+fix(Math.round(this.vertices[i]),4)+"</span><span class='matrix'>"+fix(Math.round(this.vertices[i+1]),4)+"</span><span class='matrix rborder'>"+1+"</span>";
                html += "<br>";
            }
            html += "<hr>("+Math.round(this.xl)+",";
            html += Math.round(this.yt)+")";
            html += " - ("+Math.round(this.xr)+",";
            html += Math.round(this.yb)+")";
            document.getElementById(dump).innerHTML = html;
        }
                   
/* scale -------------------------------------------------------------
    x' = x * a
    y' = y * d
--------------------------------------------------------------------*/                       
        this.scale = function(a,d) {
            for (var i = 0; i < this.vertices.length; i+=2) {
                this.vertices[i] *= a;
                this.vertices[i+1] *= d;
            }
            this.boundingbox();
        }
         
/* shear -------------------------------------------------------------
    x' = x + y * c
    y' = x * b + y
--------------------------------------------------------------------*/                       
        this.shear = function(b,c) {
            for (var i = 0; i < this.vertices.length; i+=2) {
                var t = this.vertices[i];
                this.vertices[i] += c * this.vertices[i+1];
                this.vertices[i+1] += b * t;
            }
            this.boundingbox();
        }

/* rotate ------------------------------------------------------------
    x' = x * cos(theta) + y * sin(theta)
    y' = x * -sin(theta) + y * cos(theta)
--------------------------------------------------------------------*/                       
        this.rotate = function(theta) {
            var r = radians(theta);
            var c = Math.cos(r);
            var s = Math.sin(r);
            for (var i = 0; i < this.vertices.length; i+=2) {
                var t = c * this.vertices[i] + -s * this.vertices[i+1];
                this.vertices[i+1] = Math.round(s * this.vertices[i] + c * this.vertices[i+1]);
                this.vertices[i] = Math.round(t);
            }
            this.boundingbox();
        }
    
/* transform ---------------------------------------------------------
    x' = ax + cy + e
    y' = bx + dy + f
--------------------------------------------------------------------*/           
        this.transform = function(a,b,c,d,e,f) {
            for (var i = 0; i < this.vertices.length; i+=2) {
                var t = a * this.vertices[i] + c * this.vertices[i+1] + e;
                this.vertices[i+1] = Math.round(b * this.vertices[i] + d * this.vertices[i+1] + f);
                this.vertices[i] = Math.round(t);
            }
            this.boundingbox();
        }
         
/* scramble ----------------------------------------------------------
    scramble vertices
--------------------------------------------------------------------*/           
        this.scramble = function() {
            for (var i = 0; i < this.vertices.length; i+=2) {
                var xt = this.vertices[i];
                var yt = this.vertices[i+1];
                var n = this.vertices.length/2-1;
                var r = 2*fnr(0,n); 
                this.vertices[i] = this.vertices[r];
                this.vertices[i+1] = this.vertices[r+1];
                this.vertices[r] = xt;
                this.vertices[r+1] = yt;
            }
            this.boundingbox();
        }
           
/* disturb -----------------------------------------------------------
    x' = x + fnr(-perturbation,perturbation)
    y' = y + fnr(-perturbation,perturbation)
--------------------------------------------------------------------*/           
        this.disturb = function(perturbation) {
            for (var i = 0; i < this.vertices.length; i+=2) {
                this.vertices[i] += fnr(-perturbation,perturbation);
                this.vertices[i+1] += fnr(-perturbation,perturbation);
            }
            this.boundingbox();
        }
                      
/* getCenterX --------------------------------------------------------
    returns x coordinate of center of bounding box
--------------------------------------------------------------------*/           
        this.getCenterX = function () {
            return (this.xl + this.xr) / 2;
        }

/* getCenterY --------------------------------------------------------
    returns y coordinate of center of bounding box
--------------------------------------------------------------------*/           
        this.getCenterY = function () {
            return (this.yt + this.yb) / 2;
        }
           
/* getWidth ----------------------------------------------------------
    returns width of bounding box
--------------------------------------------------------------------*/           
        this.getWidth = function () {
            return this.xr - this.xl;
        }

/* getHeight ---------------------------------------------------------
    returns height of bounding box
--------------------------------------------------------------------*/           
        this.getHeight = function () {
            return this.yb - this.yt;
        }
          
/* clip -----------------------------------------------------
    draws and clips polygon
    c is context
--------------------------------------------------------------------*/    
        this.clip = function(c) {
            c.beginPath();
            var x = this.vertices[0];
            var y = this.vertices[1];
            c.moveTo(x,y);
            for (var i = 2; i < this.vertices.length; i+=2) {
                x = this.vertices[i];
                y = this.vertices[i+1];
                c.lineTo(x,y);
            }
            c.closePath();
            c.clip();
        }
            
/* strokeQuadratic -----------------------------------------------------
    draws and strokes polygon
    c is context
    clr is strokeStyle
    (px,py) is control point
--------------------------------------------------------------------*/           
           this.strokeQuadratic = function(c,clr,px,py) {
            c.beginPath();
            var x = this.vertices[0];
            var y = this.vertices[1];
//            var px = fnr(0,CANVAS.width); //this.getCenterX();
//            var py = fnr(0,CANVAS.height); //this.getCenterY();
            c.moveTo(x,y);
            for (var i = 2; i < this.vertices.length; i+=2) {
                x = this.vertices[i];
                y = this.vertices[i+1];
                c.quadraticCurveTo(px,py,x,y);
            }
            c.closePath();
            c.strokeStyle = clr;    
            c.stroke();
        }

/* fillQuadratic -------------------------------------------------------
    draws and fills polygon
    c is context
    clr is fillStyle
    (px,py) is control point
--------------------------------------------------------------------*/               
           this.fillQuadratic = function(c,clr,px,py) {
            c.beginPath();
            var x = this.vertices[0];
            var y = this.vertices[1];
//            var px = fnr(0,CANVAS.width); //this.getCenterX();
//            var py = fnr(0,CANVAS.height); //this.getCenterY();
            c.moveTo(x,y);
            for (var i = 2; i < this.vertices.length; i+=2) {
                x = this.vertices[i];
                y = this.vertices[i+1];
                c.quadraticCurveTo(px,py,x,y);
            }
            c.closePath();
            c.fillStyle = clr;    
            c.fill();
        }
           
        return this;

    } // end Polygon

/********* Canvas Initialization ************************************/

/* Useful global variables -------------------------------------------
--------------------------------------------------------------------*/
    var CANVAS;
    var CONTEXT;
    
    function initializeCanvas(cvs) {
        CANVAS = document.getElementById(cvs);
        CONTEXT = CANVAS.getContext("2d");
    }            
            
/* Convert degrees to radians ----------------------------------------
--------------------------------------------------------------------*/
    function radians(degrees) {
        return degrees * Math.PI / 180;
    }

/********* END ******************************************************/    