﻿function doPostB1(){
			var b1= new Image();
			b1.src="bottleOpeners/BO1.png";
			CANVAS.width=b1.width;
			CANVAS.height=b1.height;
			CONTEXT.drawImage(b1,0,0);	
					
}
function doPostB2(){
			var b2= new Image();
			b2.src="bottleOpeners/BO2.png";
			CANVAS.width=b2.width;
			CANVAS.height=b2.height;
			CONTEXT.drawImage(b2,0,0);	
}