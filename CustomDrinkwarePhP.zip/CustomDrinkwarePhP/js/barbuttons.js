﻿function doPostE1(){
			var E1= new Image();
			e1.src="barware/coaster.png";
			CANVAS.width=e1.width;
			CANVAS.height=e1.height;
			CONTEXT.drawImage(e1,0,0);	
					
}
function doPostE2(){
			var e2= new Image();
			e2.src="barware/flask.png";
			CANVAS.width=e2.width;
			CANVAS.height=e2.height;
			CONTEXT.drawImage(e2,0,0);	
}
function doPostE3(){
			var e3= new Image();
			e3.src="barware/shaker.png";
			CANVAS.width=e3.width;
			CANVAS.height=e3.height;
			CONTEXT.drawImage(e3,0,0);	
}
