﻿var supplies ="";
function doPostE1(){
			var e1= new Image();
			e1.src="barware/Coasterv3.png";
			CANVAS.width=e1.width;
			CANVAS.height=e1.height;
			CONTEXT.drawImage(e1,0,0);	
			supplies="Coaster";
					
}
function doPostE2(){
			var e2= new Image();
			e2.src="barware/flask.png";
			CANVAS.width=e2.width;
			CANVAS.height=e2.height;
			CONTEXT.drawImage(e2,0,0);	
			supplies="Flask";
}
function doPostE3(){
			var e3= new Image();
			e3.src="barware/shakerv4.png";
			CANVAS.width=e3.width;
			CANVAS.height=e3.height;
			CONTEXT.drawImage(e3,0,0);	
			supplies="Shaker";
}
