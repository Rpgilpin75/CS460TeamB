﻿var cust="";
function doPostC1(){
			var c1= new Image();
			c1.src="images/c1v2.png";
			CONTEXT.drawImage(c1,CANVAS.width / 2 - c1.width / 2, CANVAS.height / 3 - c1.height / 3);
			cust ="cross";			
}
function doPostC2(){
			var c2= new Image();
			c2.src="images/c2v2.png";
			CONTEXT.drawImage(c2,CANVAS.width / 2 - c2.width / 2, CANVAS.height / 3 - c2.height / 3);			
			cust = "compass";
}
function doPostC3(){
			var c3= new Image();
			c3.src="images/c3.png";
			CONTEXT.drawImage(c3,CANVAS.width / 2 - c3.width / 2, CANVAS.height / 3 - c3.height / 3);
			cust="star";			
}
function doPostC4(){
			var c4= new Image();
			c4.src="images/c4.png";
			CONTEXT.drawImage(c4,CANVAS.width / 2 - c4.width / 2, CANVAS.height / 3 - c4.height / 3);			
			cust ="heart";
}
function doPostC5(){
			var c5= new Image();
			c5.src="images/c5.png";
			CONTEXT.drawImage(c5,CANVAS.width / 2 - c5.width / 2, CANVAS.height / 3 - c5.height / 3);			
			cust ="lightning";
}
function doPostC6(){
			var c6= new Image();
			c6.src="images/c6.png";
			CONTEXT.drawImage(c6,CANVAS.width / 2 - c6.width / 2, CANVAS.height / 3 - c6.height / 3);			
			cust="batman";
}
