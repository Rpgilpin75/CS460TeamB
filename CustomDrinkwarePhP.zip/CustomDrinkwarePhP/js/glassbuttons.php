<?Php
function doPostG1(){
			var g1= new Image();
			g1.src="GlassImg/pint.png";
			CANVAS.width=g1.width;
			CANVAS.height=g1.height;
			CONTEXT.drawImage(g1,0,0);
			var product = "1";	

					
}
function doPostG2(){
			var g2= new Image();
			g2.src="GlassImg/whiskey.png";
			CANVAS.width=g2.width;
			CANVAS.height=g2.height;
			CONTEXT.drawImage(g2,0,0);	
			var product = "2";		
}
function doPostG3(){
			var g3= new Image();
			g3.src="GlassImg/pilsner.png";
			CANVAS.width=g3.width;
			CANVAS.height=g3.height;
			CONTEXT.drawImage(g3,0,0);			
}
function doPostG4(){
			var g4= new Image();
			g4.src="GlassImg/snifter.png";
			CANVAS.width=g4.width;
			CANVAS.height=g4.height;
			CONTEXT.drawImage(g4,0,0);			
}
function doPostG5(){
			var g5= new Image();
			g5.src="GlassImg/shot_v2.png";
			CANVAS.width=g5.width;
			CANVAS.height=g5.height;
			CONTEXT.drawImage(g5,0,0);			
}
?>
