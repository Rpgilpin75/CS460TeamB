﻿
function doSubmit() {
	
	var container = document.getElementById('container'); 
	var m = document.getElementById('month').value;
	var y = document.getElementById('year').value;
	var input = new Date(m + " 1, " + y);

	if((m != "" && y != "") && isNaN(input) == false ){
		var input = new Date(m + " 1, " + y);
		container.innerHTML = cal(input);
	}
	else
	{
		alert('Enter a valid date!');
	}
}

function cal(d) {	
	var day = d.getDay();
	var dom = d.getDate();
	var month = d.getMonth()+1;
	var year = d.getFullYear();
	var dim = getDIM(month, year);
	
	var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
	var months = ['none', 'January','February','March','April','May','June','July', 'August', 'September', 'October', 'November', 'December'];
	
		var br = "<br>"
	var html = "";
	
		html += months[month] + br + year + br + dom + br + days[day] + br + dim + br;
	container.innerHTML = html;
	
		for (var i = 0; i<days.length; i++) {
		html += " " + days[i].charAt(0);
	}
	html += br; 
	
		var newDay = new Date(months[month] + " 1, " + year);
	var startDay = parseInt(newDay.getDay());
	
		for(var i = 0; i <= dim; i++){
		if(i < startDay) {
			html += " * ";	
		} 
		else
		{
		html += " " + i;
		}
		
		if (i % 6 === 0 && i != 0){
			html+= "<br>";
		}
	}
	var calText = html;
	html = "";
	return calText; }

function getDIM(m, y) { 
   	var dim =  /8|3|5|10/.test(--m)?30:m==1?(!(y%4)&&y%100)||!(y%400)?29:28:31;
   	return dim;
}

function doReset() {
	var td = new Date();
	container.innerHTML = cal(td);
	document.getElementById('month').value = "";
	document.getElementById('year').value = "";
}