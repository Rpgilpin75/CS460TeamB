<html>
<head>
	<meta charset="utf-8">
	<title>Custom Drinkware</title>
	<link href="images/avatar.png" rel="shortcut icon" type="image/png">
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<script src="js/glassbuttons.js" type="text/javascript"></script>
	<script src="js/bottleopeners.js" type="text/javascript"></script>
	<script src="js/barbuttons.js" type="text/javascript"></script>
	<script src="js/customize.js" type="text/javascript"></script>
	<style type="text/css">
	fieldset {
	margin: .1in 0in .1in .25in;
	float: left;
	border-radius: 12px;
}
	input, select {
	display: block;
}
	input[type=text] {
	width: 170px;
}
	input[type=button], input[type=reset] {
	display: block;
	clear: left;
	width: .75in;
	margin: .05in;
}
	#out {
	text-align: center;
}
	#out span {
	display: block;
	font-size: 18pt;
	width: 600px;
}
	hr {
	clear: left;

}	</style>

	<script type="text/javascript">
	
	</script>
	
</head>

<body>
	<header>
	</header>
	<nav>
			<ul>	
			<li><a href="Glassware.php">Glassware</a></li>
			<li><a href="BottleOpeners.php">Bottle Openers</a></li>
			<li><a href="BarSupplies.php">Bar Supplies</a></li>
			<li><a href="userprofile.php">Profile</a></li>
			<li><a href="logout.php">Logout</a></li>

								</ul>
	</nav>
	<aside>
	</aside>
	<section>
		<?php 
session_start();   //check login




?>
	</section>
	<footer>
	</footer>
</body>
</html>