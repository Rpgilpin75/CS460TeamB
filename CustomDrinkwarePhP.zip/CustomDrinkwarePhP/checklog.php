<html>
<head>
	<meta charset="utf-8">
	<title>Custom Drinkware</title>
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<style type="text/css">
	</style>
	<script type="text/javascript">
	 function() goHome {
	 goto index.php;
	 }
	</script>
	
</head>

<body>
<header>
	</header>
	<nav>
		<ul>
			<li><a href="Index.php">Home</a></li>		
			<li><a href="Glassware.php">Glassware</a></li>
			<li><a href="BottleOpeners.php">Bottle Openers</a></li>
			<li><a href="BarSupplies.php">Bar Supplies</a></li>
			<li><a href="Login.php">Login</a></li>
			<li><a href="register.php">Register</a></li>
					</ul>
	</nav>
<aside>
	<h1>Welcome Back Customizer!</h1>
	</aside>
	<section>

<?php 
session_start();  //establish session

//get values from form
$name =  test_input($_POST["name"]);
$pass = test_input($_POST["password"]);
      	
///PHP variables to connect to db
$servername = "frodo.bentley.edu";
$username = "cs460teamb";
$password = "mysql";
$dbname ="cs460teamb";

//this is the connection to the database
$conn = mysqli_connect($servername,$username,$password,$dbname);

// Perform SQL query
$query = "SELECT * FROM Login WHERE Username='$name'";
$result = mysqli_query($conn, $query) or die('Query failed: ' . mysqli_errno($conn));
$rows = mysqli_num_rows($result);//no rows = no access

//if userid not in login table, go to login page and try again
if ($rows < 1) header("Location: index.html");

/*
//print contents of login table to webpage, useful when debugging
echo "<table>\n";
//loop over result set. Print a table row for each record
while ($line = mysqli_fetch_array($result, MYSQL_ASSOC)) {
    echo "\t<tr>\n";
    //inner loop. Print each table field value for a record
    foreach ($line as $col_value) {
        echo "\t\t<td>$col_value</td>\n";
    }
    echo "\t</tr>\n";
}
echo "</table>\n";
*/

//get login table record for userid
$line = mysqli_fetch_array($result, MYSQL_ASSOC);

//cherck password. If not correct, go to login page and try again
if ($pass!=$line['PASS']) header("Location: login.php");

//save login record as session data, data persists over entire session
$_SESSION['name'] = $line['USERNAME'];
$_SESSION['pass'] = $line['PASS'];
/*
// Free resultset
mysqli_free_result($result);

//update last time logged in 
$update = "UPDATE Login SET last=now() WHERE UserID='$name'";
mysqli_query($conn, $update) or die('Login time update failed : ' . mysqli_errno($conn));

// Close connection
mysqli_close($conn);

*/
//create session variable containing correct login status for use in other pages
      	$_SESSION['login']="yes";
      	
           
      	echo "<p style='text-align:center;'><img src='images/avatar.png'/></p>";
      	
function test_input($data){
     $data = trim($data);
     $data = stripslashes($data);
     $data = htmlspecialchars($data);
     return $data;
}

?>
</section>
<footer>
	</footer>

</body>

</html>
