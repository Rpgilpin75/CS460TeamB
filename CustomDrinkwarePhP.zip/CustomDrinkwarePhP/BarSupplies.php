﻿<html>
<head>
	<meta charset="utf-8">
	<title>Bar Supplies</title>
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<style type="text/css">
	</style>
	<script type="text/javascript">
	
	</script>
</head>
<body>
	<header>
	</header>
	<nav>
		<ul>
			<li><a href="Glassware.html">Glassware</a></li>
			<li><a href="BottleOpeners.html">Bottle Openers</a></li>
			<li><a href="BarSupplies.html">Bar Supplies</a></li>
						
		
					</ul>
	</nav>
	<aside>
	
	</aside>
	<section>
		<img src="images/avatar.png">
	</section>
	<footer>
	</footer>
</body>
</html>