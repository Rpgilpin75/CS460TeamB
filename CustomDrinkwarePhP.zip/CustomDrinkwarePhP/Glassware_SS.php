﻿<html>
<head>
	<meta charset="utf-8">
	<title>Glassware</title>
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<script src="js/glassbuttons.js" type="text/javascript"></script>
	<script src="js/bottleopeners.js" type="text/javascript"></script>
	<script src="js/barbuttons.js" type="text/javascript"></script>
	<script src="js/customize.js" type="text/javascript"></script>
	<style type="text/css">
	fieldset {
	margin: .1in 0in .1in .25in;
	float: left;
	border-radius: 12px;
}
	input, select {
	display: block;
}
	input[type=text] {
	width: 170px;
}
	input[type=button], input[type=reset] {
	display: block;
	clear: left;
	width: .75in;
	margin: .05in;
}
	#out {
	text-align: center;
}
	#out span {
	display: block;
	font-size: 18pt;
	width: 600px;
}
	hr {
	clear: left;

	</style>
	<?php //PHP HERE//
session_start();  //establish session


//PHP variables to connect to db
$servername = "frodo.bentley.edu";
$username = "cs460teamb";
$password = "mysql";
$dbname ="cs460teamb";

//this is the connection to the database
$conn = mysqli_connect($servername,$username,$password,$dbname);
 
//check connection and if it does not work throw a PHP error indicating that it doesn't work
if ($conn-> connect_error){
	die("connect failed: " . $conn->connect_error);
}
//echo "Database connected successfully";
//echo "<br>";
?>
	<script type="text/javascript">
	//initializes the canvas variables
	var CANVAS;
	var CONTEXT;
	var gname;
//this sets up the physical canvas when the page loads	
function setup() {
			CANVAS = document.getElementById("canvas");
			CONTEXT = CANVAS.getContext("2d");
}

//ignore these they do nothing
function doSubmit() {
			var select = document.getElementById("sel");
			var image = document.getElementById("img");
			//make this a PHP function to select all of the button functions
			//and calculate the price of what was selected... think of logic for this			
}
						
function doReset() {
			var img= new Image();
			img.src="images/reset.png";
			CONTEXT.drawImage(img,0,0); 
			//have a PHP formula here to subtract the calculated value 
			//by itself to cover up any prior iterations of 
			//the user's selection
/*}
function doPostG1(){
			var g1= new Image();
			g1.src="GlassImg/pint.png";
			CANVAS.width=g1.width;
			CANVAS.height=g1.height;
			CONTEXT.drawImage(g1,0,0);
			var gname = "pint";				
}
function doPostG2(){
			var g2= new Image();
			g2.src="GlassImg/whiskey.png";
			CANVAS.width=g2.width;
			CANVAS.height=g2.height;
			CONTEXT.drawImage(g2,0,0);	
			var gname = "whiskey";	
}
function doPostG3(){
			var g3= new Image();
			g3.src="GlassImg/pilsner.png";
			CANVAS.width=g3.width;
			CANVAS.height=g3.height;
			CONTEXT.drawImage(g3,0,0);
			var gname = "pilsner";			
}
function doPostG4(){
			var g4= new Image();
			g4.src="GlassImg/snifter.png";
			CANVAS.width=g4.width;
			CANVAS.height=g4.height;
			CONTEXT.drawImage(g4,0,0);
			var gname = "snifter";			
}
function doPostG5(){
			var g5= new Image();
			g5.src="GlassImg/shot_v2.png";
			CANVAS.width=g5.width;
			CANVAS.height=g5.height;
			CONTEXT.drawImage(g5,0,0);
			var gname = "shot";			
}

var price;
if(gname= "pint"){
	price = "<?php echo $pint;?>";
	}else if (gname ="whiskey"){
		price = "<?php echo $whiskey;?>";
		}else if (gname= "pilsner"){
			price = "<?php echo $pilsner;?>";
			}else if (gname= "snifter"){
				price = "<?php echo $snifter;?>";
				}else if (gname= "shotr"){
					price = "<?php echo $shot;?>";
					}
					else price="not found"
					*/}


	</script>
	

</head>
<body>
	<header>
	</header>
	<nav>
		<ul>
			<li><a href="Index.php">Home</a></li>		
			<li><a href="Glassware.php">Glassware</a></li>
			<li><a href="BottleOpeners.php">Bottle Openers</a></li>
			<li><a href="BarSupplies.php">Bar Supplies</a></li>
			<li><a href="Login.php">Login</a></li>
			<li><a href="register.php">Register</a></li>
					</ul>
	</nav>
	<aside>
	<?php
$pintsql= "SELECT PRODUCT_PRICE FROM PRODUCT WHERE PRODUCT_NAME = 'Pint'";
$pintresult=mysqli_query($conn, $pintsql);

$whiskeysql= "SELECT PRODUCT_PRICE FROM PRODUCT WHERE PRODUCT_NAME = 'Whiskey'";
$whiskeyresult=mysqli_query($conn, $whiskeysql);


if (mysqli_num_rows($pintresult) > 0) {
// output data of each row so that we can see it
    while($row = mysqli_fetch_assoc($pintresult)) {
   $pint =  $row["PRODUCT_PRICE"];
      echo $pint;
    }
} else {
    echo "0 results";
}


if (mysqli_num_rows($whiskeyresult) > 0) {
// output data of each row so that we can see it
    while($row = mysqli_fetch_assoc($pintresult)) {
   $whiskey =  $row["PRODUCT_PRICE"];
      echo $whiskey;
    }
} else {
    echo "0 results";
}

/*
//sql statement to pull all product names and prices from our table in the database
$sql = "SELECT PRODUCT_NAME, PRODUCT_PRICE FROM PRODUCT WHERE PRODUCT_CATEGORY = 'Glass'";
//Stores the result fo the query in a variable to be used in the loop below
$result = mysqli_query($conn, $sql);

//check to see that result variable holds and has pulled the correct number of rows
if (mysqli_num_rows($result) > 0) {
// output data of each row so that we can see it
    while($row = mysqli_fetch_assoc($result)) {
       echo "<br>". "Name: " . $row["PRODUCT_NAME"]. "<br>". "Price: " . $row["PRODUCT_PRICE"]. "<br>";
       
    }
} else {
    echo "0 results";
}
*/
mysqli_close($conn);
?>
	</aside>
	<section>
		<form id="frm">
			<fieldset>
				<legend>Glass Type</legend>
					<input id="G1" type="button" onclick="doPostG1();" value="Pint"><!--if the input = G1 pull this line then call G1?? take time and think-->
					<input id="G2" type="button" onclick="doPostG2();" value="Whiskey">
					<input id="G3" type="button" onclick="doPostG3();" value="Pilsner">
					<input id="G4" type="button" onclick="doPostG4();" value="Snifter">
					<input id="G5" type="button" onclick="doPostG5();" value="Shot">
					<hr>Customization
					<input id="cus1" type="button" onclick="doPostC1();" value="Cross">
					<input id="cus2" type="button" onclick="doPostC2();" value="Compass">
					<input id="cus3" type="button" onclick="doPostC3();" value="Star">
					<input id="cus4" type="button" onclick="doPostC4();" value="Heart">
					<input id="cus5" type="button" onclick="doPostC5();" value="Lightning">
					<input id="cus6" type="button" onclick="doPostC6();" value="Batman">
					<hr><br>
					<input id="res" type="reset" onclick="doReset();" value="Reset">
						
						
								</fieldset>

				<fieldset>
					<div id="out">
					<canvas id="canvas" width="300" height="450"></canvas>
											</div>
			</fieldset>	
			<fieldset>
					
									</fieldset>	
		</form>
		</section>
		
	<footer>
	</footer>
</body>
</html>