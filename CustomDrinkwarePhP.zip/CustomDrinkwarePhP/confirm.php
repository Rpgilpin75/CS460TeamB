<html>
<head>
	<meta charset="utf-8">
	<title>Custom Drinkware</title>
	<link href="images/avatar.png" rel="shortcut icon" type="image/png">
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<script src="js/glassbuttons.js" type="text/javascript"></script>
	<script src="js/bottleopeners.js" type="text/javascript"></script>
	<script src="js/barbuttons.js" type="text/javascript"></script>
	<script src="js/customize.js" type="text/javascript"></script>
	<style type="text/css">
	fieldset {
	margin: .1in 0in .1in .25in;
	float: left;
	border-radius: 12px;
	color:black;
}
	input, select {
	display: block;
}
	input[type=text] {
	width: 170px;
}
	input[type=button], input[type=reset] {
	display: block;
	clear: left;
	width: .75in;
	margin: .05in;
}
	#out {
	text-align: center;
}
	#out span {
	display: block;
	font-size: 18pt;
	width: 600px;
}
	hr {
	clear: left;

}	

	h1{
	
	color:black;
	text-align:center;
}
	font{
	
	color:black;
}
</style>
<script type="text/javascript">

//var tprice=sessionStorage.getItem('total');
//	alert(tprice);

</script>

	<script type="text/javascript">
				</script>
	
</head>

<body>
	<header>
	</header>
	<nav>
			<ul>	
			<li><a href="Glassware.php">Glassware</a></li>
			<li><a href="BottleOpeners.php">Bottle Openers</a></li>
			<li><a href="BarSupplies.php">Bar Supplies</a></li>
			<li><a href="userprofile.php">Profile</a></li>
			<li><a href="logout.php">Logout</a></li>

								</ul>
	</nav>
	<aside>
	</aside>
	<section>
		<?php 
session_start();
//post from payment form
$payid = "DEFAULT";
$cdnum = test_input($_POST["CDnum"]);
$billaddress = test_input($_POST["billaddress"]);
$billcity = test_input($_POST["billcity"]);
$billstate = test_input($_POST["billstate"]);
$billzip = test_input($_POST["billzip"]);
$expdate = test_input($_POST["expdate"]);
$noc =test_input($_POST["noc"]);

//setting of session variables from price table
$_SESSION['CDnum']=$cdnum;
$_SESSION['billaddress']=$billaddress;
$_SESSION['billcity']=$billcity;
$_SESSION['billstate']=$billstate;
$_SESSION['billzip']=$billzip;
$_SESSION['expdate']=$expdate;
$_SESSION['noc']=$noc;

//pulled pricing, product, and customer variables
$tprice=$_SESSION['totalprice'];
$prodname=$_SESSION['productname'];
$custname=$_SESSION['customname'];
$cusid=$_SESSION['customer'];

//date variable
//$date=date('Y-m-d');
//echo($date);
//$_SESSION['orddate']=$date;


  	
///PHP variables to connect to db
$servername = "frodo.bentley.edu";
$username = "cs460teamb";
$password = "mysql";
$dbname ="cs460teamb";

//this is the connection to the database
$conn = mysqli_connect($servername,$username,$password,$dbname);

//Insert the values into the various tables
//payment
$insertpay = "INSERT INTO PAYMENT(PAYMENT_ID, CREDIT_DEBIT_CARD_NUMBER, EXPIRATION_DATE, BILLING_ADDRESS, BILLING_ZIP, CUSTOMER_ID, BILLING_CITY, BILLING_STATE, NAME_ON_CARD) VALUES ('$payid', '$cdnum', '$expdate', '$billaddress', '$billzip', '$cusid', '$billcity', '$billstate', '$noc')";
	$ipResult =mysqli_query($conn, $insertpay) or die('Insert Failed for payment: ' . mysqli_errno($conn));

echo('
<form action="confirm.php">
<h1>Please Review Your Order Prior to Confirmation</h1>
<fieldset>
<h1>Shipping Summary</h1><hr>');
echo("Recipient: ");
echo($_SESSION['recipient']); 
echo("</br>");
echo("Recipient Phone Number:");
echo($_SESSION['recphone']);
echo("</br>");
echo("Shipping Address: ");
echo($_SESSION['shipaddress']);
echo("</br>");
echo("Shipping City: ");
echo($_SESSION['shipcity']); 
echo("</br>");
echo("Shipping State: "); 
echo($_SESSION['shipstate']); 
echo("</br>");
echo("Shipping Zip Code: "); 
echo($_SESSION['shipzip']); 
echo("</br>");
echo('
</fieldset>
<fieldset>
<h1>Payment Summary</h1><hr>');
echo("Cardholder Name: ");
echo($_SESSION['noc']);
echo("</br>");
echo("Credit Card Number: ");
echo($_SESSION['CDnum']);
echo("</br>");
echo("Expiration Date: ");
echo($_SESSION['expdate']);
echo("</br>");
echo("Billing Address: ");
echo($_SESSION['billaddress']);
echo("</br>");
echo("Billing City: ");
echo($_SESSION['billcity']);
echo("</br>");
echo("Billing State: ");
echo($_SESSION['billstate']);
echo("</br>");
echo("Billing Zip Code: ");
echo($_SESSION['billzip']);
echo("</br>");
echo('
</fieldset>
<fieldset>
<h1>Customization Summary</h1><hr>');
echo("Product: ");
echo($_SESSION['productname']);
echo("</br>");
echo("Customization: ");
echo($_SESSION['customname']);
echo("</br>");
echo("Price: ");
echo($_SESSION['totalprice']);
echo("</br>");
echo("Date Ordered: ");
echo($_SESSION['today']);
echo("</br>");
echo('
</form>
');

$q = "SELECT MAX(PAYMENT_ID) AS 'newid' FROM payment WHERE customer_id='$cusid'";
$r = mysqli_query($conn, $q) or die('Query failed: ' . mysqli_errno($conn));
$l = mysqli_fetch_array($r, MYSQL_ASSOC);


//Session variable for most recent payment ID
//echo($l['newid']);
$_SESSION['payid']=$l['newid'];
//echo($_SESSION['payid']);
// Close connection
mysqli_close($conn);


 
function test_input($data){
     $data = trim($data);
     $data = stripslashes($data);
     $data = htmlspecialchars($data);
     return $data;
}
echo "<link href='css/page.css' rel='stylesheet' type='text/css'/>";
echo('
<hr>
<form action="thankyou.php" method="post">
<table>
<tr><td colspan="2"><input type="submit" value="Confirm"/></td></tr>
</table>
</form>
</fieldset>');

?>


	</section>
	<footer>
	</footer>
</body>
</html>