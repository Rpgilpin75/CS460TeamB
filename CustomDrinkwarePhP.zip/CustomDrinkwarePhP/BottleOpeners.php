﻿<html>
<head>
<?php //PHP HERE//
session_start();  //establish session


//PHP variables to connect to db
$servername = "frodo.bentley.edu";
$username = "cs460teamb";
$password = "mysql";
$dbname ="cs460teamb";

//this is the connection to the database
$conn = mysqli_connect($servername,$username,$password,$dbname);
 
//check connection and if it does not work throw a PHP error indicating that it doesn't work
if ($conn-> connect_error){
	die("connect failed: " . $conn->connect_error);
}
//echo "Database connected successfully";
//echo "<br>";


//customizations
$csql ="Select * from Customization";
$cresult = mysqli_query($conn, $csql);
$customizations=array();

if (mysqli_num_rows($cresult) > 0) {
// output data of each row so that we can see it
    while($row = mysqli_fetch_assoc($cresult)) {
       //echo "<br>". "Name: " . $row["PRODUCT_NAME"]. "<br>". "Price: " . $row["PRODUCT_PRICE"]. "<br>";
       $customizations[$row["CUSTOMIZATION_TYPE"]]=$row["CUSTOMIZATION_PRICE"];
    }
} else {
    echo "0 results";
}


$openers=array();
//sql statement to pull all product names and prices from our table in the database
$sql = "SELECT PRODUCT_NUMBER, PRODUCT_NAME, PRODUCT_PRICE FROM PRODUCT WHERE PRODUCT_CATEGORY = 'BottleOpener'";
//Stores the result fo the query in a variable to be used in the loop below
$result = mysqli_query($conn, $sql);

//check to see that result variable holds and has pulled the correct number of rows
if (mysqli_num_rows($result) > 0) {
// output data of each row so that we can see it
    while($row = mysqli_fetch_assoc($result)) {
       //echo "<br>". "Name: " . $row["PRODUCT_NAME"]. "<br>". "Price: " . $row["PRODUCT_PRICE"]. "<br>";
       $openers[$row["PRODUCT_NAME"]]=$row["PRODUCT_PRICE"];
    }
} else {
    echo "0 results";
}

	
$hand =$openers["Hand"]; 
$mounted= $openers["Mounted"];

$cross= $customizations["Cross"];
$compass=$customizations["Compass"];
$star=$customizations["Star"];
$heart=$customizations["Heart"]; 
$lightning= $customizations["Lightning"];
$batman=$customizations["Batman"];



?>
	<meta charset="utf-8">
	<title>Bottle Openers</title>
	<link href="images/avatar.png" rel="shortcut icon" type="image/png">
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<!--<script src="js/glassbuttons.js" type="text/javascript"></script>-->
	<script src="js/bottleopeners.js" type="text/javascript"></script>
	<!--<script src="js/barbuttons.js" type="text/javascript"></script>-->
	<script src="js/customizeBO.js" type="text/javascript"></script>
	<style type="text/css">
	fieldset {
	margin: .1in 0in .1in .25in;
	float: left;
	border-radius: 12px;
}
	input, select {
	display: block;
}
	input[type=text] {
	width: 170px;
}
	input[type=button], input[type=reset] {
	display: block;
	clear: left;
	width: .75in;
	margin: .05in;
}
	#out {
	text-align: center;
}
	#out span {
	display: block;
	font-size: 18pt;
	width: 600px;
}
	hr {
	clear: left;
}
	</style>
	<script type="text/javascript">
	//price variables
	//initializes the canvas variables
	var CANVAS;
	var CONTEXT;
	var CANVAS2;
	var ctx;
	var pPrice;
	var cPrice;	
	var tPrice;
	
	
//this sets up the physical canvas when the page loads	
function setup() {
			CANVAS = document.getElementById("canvas");
			CONTEXT = CANVAS.getContext("2d");
			CANVAS2 = document.getElementById("canvas2");
			ctx = CANVAS2.getContext("2d");
			ctx.fontColor="black";
			ctx.font= "30 arial";
}
						
function doReset() {
			var img= new Image();
			img.src="images/reset.png";
			CONTEXT.drawImage(img,0,0);
			ctx.drawImage(img,0,0); 
			opener="";
			cust="";
			pPrice=0;
			cPrice=0;
			tPrice=0;
}

//variables passed from java script alerted into js popup windows as proof
var hand= <?php echo json_encode($hand); ?>;
	//alert(pint);
	hand=parseFloat(hand);
var mounted= <?php echo json_encode($mounted); ?>;
	//alert(whiskey);
	mounted=parseFloat(mounted);		
var palert = "Please Select a Product";
var calert = "Please Select a Customization";

//PHP passed variables for customizations
var cross=<?php echo json_encode($cross); ?>;
	cross=parseFloat(cross);
var compass=<?php echo json_encode($compass); ?>;
	compass=parseFloat(compass);
var star=<?php echo json_encode($star); ?>;
	star=parseFloat(star);
var heart=<?php echo json_encode($heart); ?>;
	heart=parseFloat(heart);
var lightning=<?php echo json_encode($lightning); ?>;
	lightning=parseFloat(lightning);
var batman=<?php echo json_encode($batman); ?>;
	batman=parseFloat(batman);

function doPrice(){
if(opener == "Hand Opener"){
	//alert(pint);
	pPrice= hand;
}else if (opener =="Mounted Opener"){
	//alert(whiskey);
	pPrice = mounted;
}else{ alert(palert);
}

if(cust == "Cross"){
	//alert(cross);
	cPrice= cross;
}else if (cust =="Compass"){
	//alert(compass);
	cPrice = compass;
}else if (cust == "Star"){
	//alert(star);
	cPrice=star;
}else if (cust == "Heart"){
	//alert(heart);
	cPrice = heart;
}else if (cust == "Lightning"){
	//alert(lightning);
	cPrice = lightning;
}else if (cust == "Batman"){
	//alert(batman);
	cPrice = batman;
}

else{ alert(calert);
}

var tPrice= pPrice  +  cPrice;
//alert(tPrice);
ctx.font="20px Arial Black";
ctx.fillText(tPrice,20, 52);

var total = pPrice + cPrice;
sessionStorage.setItem('total',total);
//alert(sessionStorage.getItem('total'));
document.getElementById('total').value = total;
document.getElementById('prod').value= opener;
document.getElementById('custom').value=cust;



}
	</script>


</head>
<body>
	<header>
	</header>
	<nav>
		<ul>		
			<li><a href="Glassware.php">Glassware</a></li>
			<li><a href="BottleOpeners.php">Bottle Openers</a></li>
			<li><a href="BarSupplies.php">Bar Supplies</a></li>
			<li><a href="userprofile.php">Profile</a></li>
			<li><a href="logout.php">Logout</a></li>

					</ul>
	</nav>
	<aside>
<!--	<?php
	echo($hand);
	echo("<br>");
	echo($mounted);
	echo("<br>");

	echo($cross);
	echo("<br>");
echo($compass);
echo("<br>");
	echo($star);
echo("<br>");
	echo($heart);
echo("<br>");
	echo($lightning);
echo("<br>");
	echo($batman);
	?>
-->
	</aside>
	<section>
		<form id="frm">
			<fieldset>
				<legend>Bottle Openers</legend>
					<input id="G1" type="button" onclick="doPostB1();" value="Hand">
					<input id="G2" type="button" onclick="doPostB2();" value="Mounted">
					<hr>Customization
					<input id="cus1" type="button" onclick="doPostC1();" value="Cross">
					<input id="cus2" type="button" onclick="doPostC2();" value="Compass">
					<input id="cus3" type="button" onclick="doPostC3();" value="Star">
					<input id="cus4" type="button" onclick="doPostC4();" value="Heart">
					<input id="cus5" type="button" onclick="doPostC5();" value="Lightning">
					<input id="cus6" type="button" onclick="doPostC6();" value="Batman">
					<hr>
					<input id="sub" type="button" onclick="doPrice()" value="Price">
					<input id="res" type="reset" onclick="doReset();" value="Reset">
				</fieldset>
		</form>	
		
				<fieldset>
					<div id="out">
					<canvas id="canvas" width="300" height="450"></canvas>
					</div>
				</fieldset>	
			<fieldset><legend>Price</legend>
				<div id="price">
				<canvas id="canvas2" width="100" height="100"></canvas>
				</div>
				<form action="shipping.php" method="post">
				<input style="display:none" type="number" step="any" id="total" name="price">
				<input style="display:none" type="text" id="prod" name="prod">
				<input style="display:none" type="text" id="custom" name="custom">
				<hr>
				<input type="submit" value="Checkout">		
				</form>	
			</fieldset>	
			</section>
		
	<footer>
	</footer>
</body>
</html>