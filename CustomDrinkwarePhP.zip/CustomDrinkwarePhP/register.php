﻿<html>
<head>
	<meta charset="utf-8">
	<title>Custom Drinkware</title>
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<script src="js/glassbuttons.js" type="text/javascript"></script>
	<script src="js/bottleopeners.js" type="text/javascript"></script>
	<script src="js/barbuttons.js" type="text/javascript"></script>
	<script src="js/customize.js" type="text/javascript"></script>
	<style type="text/css">
	fieldset {
	margin: .1in 0in .1in .25in;
	float: left;
	border-radius: 12px;
}
	input, select {
	display: block;
}
	input[type=text] {
	width: 170px;
}
	input[type=button], input[type=reset] {
	display: block;
	clear: left;
	width: .75in;
	margin: .05in;
}
	#out {
	text-align: center;
}
	#out span {
	display: block;
	font-size: 18pt;
	width: 600px;
}
	hr {
	clear: left;

}	</style>

	<script type="text/javascript">
	
	</script>
	
</head>

<body>
	<header>
	</header>
	<nav>
			<ul>
			<li><a href="Index.php">Home</a></li>		
			<li><a href="Login.php">Login</a></li>
			<li><a href="register.php">Register</a></li>
					</ul>
	</nav>
	<aside>
	<!-- for when php does not show up for some reason
	<a href="registerPHP.php">PHP</a> -->
	</aside>
	<section>
		<?php 
session_start();   //check login
//if ($_SESSION['login']=="yes") {  
	
	//write to browser
echo "<link href='css/page.css' rel='stylesheet' type='text/css'/>";
echo '
<fieldset>
<h1>New User Registration</h1>
<form action="registerPHP.php" method="post">
<table>
<tr><td>First Name</td><td><input type="text" name="firstname"></td></tr><br/>
<tr><td>Last Name</td><td> <input type="text" name="lastname"></td></tr><br/>
<tr><td>Desired Username</td><td> <input type="text" name="username"></td></tr><br/>
<tr><td>Password</td><td> <input type="text" name="password"></td></tr><br/>
<tr><td>Phone Number</td><td> <input type="text" name="phone"></td></tr></br>
<tr><td>Address</td><td> <input type="text" name="address"></td></tr></br>
<tr><td>City</td><td> <input type="text" name="city"></td></tr></br>
<tr><td>State</td><td> <input type="text" name="state"></td></tr></br>
<tr><td>Zip</td><td> <input type="text" name="zip"></td></tr></br>
<tr><td colspan="2"><input type="submit" value="Create Account"/></td></tr>
</form>
</table>
</fieldset>
';
?>
	</section>
	<footer>
	</footer>
</body>
</html>