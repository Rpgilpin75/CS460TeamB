<html>
<head>
	<meta charset="utf-8">
	<title>Custom Drinkware</title>
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<script src="js/glassbuttons.js" type="text/javascript"></script>
	<script src="js/bottleopeners.js" type="text/javascript"></script>
	<script src="js/barbuttons.js" type="text/javascript"></script>
	<script src="js/customize.js" type="text/javascript"></script>
	<style type="text/css">
	fieldset {
	margin: .1in 0in .1in .25in;
	float: left;
	border-radius: 12px;
}
	input, select {
	display: block;
}
	input[type=text] {
	width: 170px;
}
	input[type=button], input[type=reset] {
	display: block;
	clear: left;
	width: .75in;
	margin: .05in;
}
	#out {
	text-align: center;
}
	#out span {
	display: block;
	font-size: 18pt;
	width: 600px;
}
	hr {
	clear: left;

}	
</style>
	<script type="text/javascript">
		</script>
	
</head>

<body>
<header>
	</header>
	<nav>
		<ul>
			<li><a href="Glassware.php">Glassware</a></li>
			<li><a href="BottleOpeners.php">Bottle Openers</a></li>
			<li><a href="BarSupplies.php">Bar Supplies</a></li>
			<li><a href="logout.php">Logout</a></li>

									</ul>
	</nav>
<aside>
<!-- comment to make the aside exude a width-->
</aside>
<section>
<?php 
session_start();  //establish session

//get values from form

//remove the $###ID="TEXT"; when table is fixed to make sure it doesnt get fucked up
$shipid = "DEFAULT";
$cusid=$_SESSION['customer'];
$recname = test_input($_POST["recname"]);
$shipaddress = test_input($_POST["shipaddress"]);
$shipcity = test_input($_POST["shipcity"]);
$shipstate = test_input($_POST["shipstate"]);
$shipzip = test_input($_POST["shipzip"]);
$recphone = test_input($_POST["recphone"]);



      	
///PHP variables to connect to db
$servername = "frodo.bentley.edu";
$username = "cs460teamb";
$password = "mysql";
$dbname ="cs460teamb";

//this is the connection to the database
$conn = mysqli_connect($servername,$username,$password,$dbname);

//Insert the values into the various tables
//shipping

//re-write this insert statement to reflect the new table schema created on 12/3
$insertship = "INSERT INTO SHIPPING(SHIPPING_ID, RECIPIENT_NAME, SHIPPING_ADDRESS, SHIPPING_CITY, shipping_state, shipping_zip, RECIPIENT_PHONE_NUMBER, customer_id) VALUES ('$shipid', '$recname', '$shipaddress', '$shipcity', '$shipstate', '$shipzip', '$recphone', '$cusid')";
	$isResult =mysqli_query($conn, $insertship) or die('Insert Failed for Shipping: ' . mysqli_errno($conn));

//}
/*
//$cresult = "SELECT * from CUSTOMER";

//print contents of customer table to webpage, useful when debugging
echo "<table>\n";
//loop over result set. Print a table row for each record
while ($line = mysqli_fetch_array($cresult, MYSQL_ASSOC)) {
    echo "\t<tr>\n";
    //inner loop. Print each table field value for a record
    foreach ($line as $col_value) {
        echo "\t\t<td>$col_value</td>\n";
    }
    echo "\t</tr>\n";
}
echo "</table>\n";

$lresult = "SELECT * from LOGIN";

//print contents of customer table to webpage, useful when debugging
echo "<table>\n";
//loop over result set. Print a table row for each record
while ($linel = mysqli_fetch_array($lresult, MYSQL_ASSOC)) {
    echo "\t<tr>\n";
    //inner loop. Print each table field value for a record
    foreach ($linel as $col_value) {
        echo "\t\t<td>$col_value</td>\n";
    }
    echo "\t</tr>\n";
}
echo "</table>\n";

//get login table record for userid
*/
// Free resultset
//mysqli_free_result($result);


// Close connection
mysqli_close($conn);


 
function test_input($data){
     $data = trim($data);
     $data = stripslashes($data);
     $data = htmlspecialchars($data);
     return $data;
}
echo "<link href='css/page.css' rel='stylesheet' type='text/css'/>";
echo'
<fieldset>
<h1>Payment Information</h1>
<form action="paymentPHP.php" method="post">
<table>
<tr><td>Credit/Debit Card Number</td><td><input type="text" name="CDnum"></td></tr><br/>
<tr><td>Expiration Date</td><td> <input type="date" name="expdate"></td></tr><br/>
<tr><td>Billing Address</td><td> <input type="text" name="billaddress"></td></tr></br>
<tr><td>Billing City</td><td> <input type="text" name="billcity"></td></tr><br/>
<tr><td>Billing State</td><td><input type="text" name="billstate"></td></tr><br/>
<tr><td>Billing Zip</td><td> <input type="text" name="billzip"></td></tr><br/>
<tr><td colspan="2"><input type="submit" value="Continue"/></td></tr>
</table>
</form>
</fieldset>
'
?>
</section>
<footer>
</footer>
</body>

</html>
