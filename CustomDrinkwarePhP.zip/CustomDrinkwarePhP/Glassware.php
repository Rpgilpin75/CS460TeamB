﻿<html>
<head>
	<meta charset="utf-8">
	<title>Glassware</title>
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<script src="js/glassbuttons.js" type="text/javascript"></script>
	<script src="js/bottleopeners.js" type="text/javascript"></script>
	<script src="js/barbuttons.js" type="text/javascript"></script>
	<script src="js/customize.js" type="text/javascript"></script>
	<style type="text/css">
	fieldset {
	margin: .1in 0in .1in .25in;
	float: left;
	border-radius: 12px;
}
	input, select {
	display: block;
}
	input[type=text] {
	width: 170px;
}
	input[type=button], input[type=reset] {
	display: block;
	clear: left;
	width: .75in;
	margin: .05in;
}
	#out {
	text-align: center;
}
	#out span {
	display: block;
	font-size: 18pt;
	width: 600px;
}
	hr {
	clear: left;

	</style>
	<script type="text/javascript">
	var CANVAS;
	var CONTEXT;
	var product;
	var customization;
	//CANVAS.width=CANVAS.innerWidth;
	//CANVAS.height=CANVAS.innerHeight;
function setup() {
			CANVAS = document.getElementById("canvas");
			CONTEXT = CANVAS.getContext("2d");
}
function doSubmit() {
			var select = document.getElementById("sel");
			var image = document.getElementById("img");
			//make this a PHP function to select all of the button functions
			//and calculate the price of what was selected... think of logic for this			
}
						
function doReset() {
			var img= new Image();
			img.src="images/reset.png";
			CONTEXT.drawImage(img,0,0); 
			//have a PHP formula here to subtract the calculated value 
			//by itself to cover up any prior iterations of 
			//the user's selection
}
	
	</script>
	

</head>
<body>
	<header>
	</header>
	<nav>
		<ul>
			<li><a href="Index.php">Home</a></li>		
			<li><a href="Glassware.php">Glassware</a></li>
			<li><a href="BottleOpeners.php">Bottle Openers</a></li>
			<li><a href="BarSupplies.php">Bar Supplies</a></li>
					</ul>
	</nav>
	<aside>
	<?php
//PHP to connect
$servername = "frodo.bentley.edu";
$username = "cs460teamb";
$password = "mysql";
$dbname ="cs460teamb";

//this is the connection to the database
//$conn = mysqli_connect($servername,$username, $password); 
$conn = mysqli_connect($servername,$username,$password,$dbname);
 
//check connection
if ($conn-> connect_error){
	die("connect failed: " . $conn->connect_error);
}
echo "Database connected successfully";
echo "<br>";

$sql = "SELECT PRODUCT_NAME, PRODUCT_PRICE FROM PRODUCT";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "<br>". "Name: " . $row["PRODUCT_NAME"]. "<br>". "Price: " . $row["PRODUCT_PRICE"]. "<br>";
    }
} else {
    echo "0 results";
}

mysqli_close($conn);
?>
	</aside>
	<section>
		<form id="frm">
			<fieldset>
				<legend>Glass Type</legend>
					<input id="G1" type="button" onclick="doPostG1();" value="Pint"><!--if the input = G1 pull this line then call G1?? take time and think-->
					<input id="G2" type="button" onclick="doPostG2();" value="Whiskey">
					<input id="G3" type="button" onclick="doPostG3();" value="Pilsner">
					<input id="G4" type="button" onclick="doPostG4();" value="Snifter">
					<input id="G5" type="button" onclick="doPostG5();" value="Shot">
					<hr>Customization
					<input id="cus1" type="button" onclick="doPostC1();" value="Cross">
					<input id="cus2" type="button" onclick="doPostC2();" value="Compass">
					<input id="cus3" type="button" onclick="doPostC3();" value="Opt 3">
					<input id="cus4" type="button" onclick="doPostC4();" value="Opt 4">
					<input id="cus5" type="button" onclick="doPostC5();" value="Opt 5">
					<input id="cus6" type="button" onclick="doPostC6();" value="Opt 6">
					<hr><br>
					<input id="res" type="reset" onclick="doReset();" value="Reset">
								</fieldset>

				<fieldset>
					<div id="out">
					<canvas id="canvas" width="300" height="450"></canvas>
											</div>
			</fieldset>	
			<fieldset>
						<!-- Get specific DB names for these line items need to fix syntax here -->
			</fieldset>	
		</form>
		</section>
	<footer>
	</footer>
</body>
</html>