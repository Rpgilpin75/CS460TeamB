﻿<html>
<head>
<?php //PHP HERE//
session_start();  //establish session

//PHP variables to connect to db
$servername = "frodo.bentley.edu";
$username = "cs460teamb";
$password = "mysql";
$dbname ="cs460teamb";

//this is the connection to the database
$conn = mysqli_connect($servername,$username,$password,$dbname);
 
//check connection and if it does not work throw a PHP error indicating that it doesn't work
if ($conn-> connect_error){
	die("connect failed: " . $conn->connect_error);
}
//echo "Database connected successfully";
//echo "<br>";


//customizations
$csql ="Select * from Customization";
$cresult = mysqli_query($conn, $csql);
$customizations=array();

if (mysqli_num_rows($cresult) > 0) {
// output data of each row so that we can see it
    while($row = mysqli_fetch_assoc($cresult)) {
       //echo "<br>". "Name: " . $row["PRODUCT_NAME"]. "<br>". "Price: " . $row["PRODUCT_PRICE"]. "<br>";
       $customizations[$row["CUSTOMIZATION_TYPE"]]=$row["CUSTOMIZATION_PRICE"];
    }
} else {
    echo "0 results";
}


$products=array();
//sql statement to pull all product names and prices from our table in the database
$sql = "SELECT PRODUCT_NUMBER, PRODUCT_NAME, PRODUCT_PRICE FROM PRODUCT WHERE PRODUCT_CATEGORY = 'Glass'";
//Stores the result fo the query in a variable to be used in the loop below
$result = mysqli_query($conn, $sql);

//check to see that result variable holds and has pulled the correct number of rows
if (mysqli_num_rows($result) > 0) {
// output data of each row so that we can see it
    while($row = mysqli_fetch_assoc($result)) {
       //echo "<br>". "Name: " . $row["PRODUCT_NAME"]. "<br>". "Price: " . $row["PRODUCT_PRICE"]. "<br>";
       $products[$row["PRODUCT_NAME"]]=$row["PRODUCT_PRICE"];
    }
} else {
    echo "0 results";
}

	
$pint =$products["Pint"]; 
$whiskey= $products["Whiskey"];
$pilsner=$products["Pilsner"];
$snifter=$products["Snifter"];
$shot=$products["Shot"];

$cross= $customizations["Cross"];
$compass=$customizations["Compass"];
$star=$customizations["Star"];
$heart=$customizations["Heart"]; 
$lightning= $customizations["Lightning"];
$batman=$customizations["Batman"];



?>
	<meta charset="utf-8">
	<title>Glassware</title>
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<script src="js/glassbuttons.js" type="text/javascript"></script>
	<script src="js/bottleopeners.js" type="text/javascript"></script>
	<script src="js/barbuttons.js" type="text/javascript"></script>
	<script src="js/customize.js" type="text/javascript"></script>
	<style type="text/css">
	fieldset {
	margin: .1in 0in .1in .25in;
	float: left;
	border-radius: 12px;
}
	input, select {
	display: block;
}
	input[type=text] {
	width: 170px;
}
	input[type=button], input[type=reset] {
	display: block;
	clear: left;
	width: .75in;
	margin: .05in;
}
	#out {
	text-align: center;
}
	#out span {
	display: block;
	font-size: 18pt;
	width: 600px;
}
	hr {
	clear: left;
}
	</style>
	<script type="text/javascript">
	//price variables
	//initializes the canvas variables
	var CANVAS;
	var CONTEXT;
	var CANVAS2;
	var ctx;
	var pPrice;
	var cPrice;	
	var tPrice;
	
	
//this sets up the physical canvas when the page loads	
function setup() {
			CANVAS = document.getElementById("canvas");
			CONTEXT = CANVAS.getContext("2d");
			CANVAS2 = document.getElementById("canvas2");
			ctx = CANVAS2.getContext("2d");
			ctx.fontColor="black";
			ctx.font= "30 arial";
}
						
function doReset() {
			var img= new Image();
			img.src="images/reset.png";
			CONTEXT.drawImage(img,0,0);
			ctx.drawImage(img,0,0); 
			glass="";
			cust="";
			pPrice=0;
			cPrice=0;
			tPrice=0;
}

//variables passed from java script alerted into js popup windows as proof
var pint= <?php echo json_encode($pint); ?>;
	//alert(pint);
	pint=parseFloat(pint);
var whiskey= <?php echo json_encode($whiskey); ?>;
	//alert(whiskey);
	whiskey=parseFloat(whiskey);
var snifter= <?php echo json_encode($snifter); ?>;
	//alert(snifter);
	snifter=parseFloat(snifter);
var pilsner= <?php echo json_encode($pilsner); ?>;
	//alert(pilsner);
	pilsner=parseFloat(pilsner);
var shot= <?php echo json_encode($shot); ?>;
	//alert(shot);	
	shot=parseFloat(shot);		
var palert = "Please Select a Product";
var calert = "Please Select a Customization";

//PHP passed variables for customizations
var cross=<?php echo json_encode($cross); ?>;
	cross=parseFloat(cross);
var compass=<?php echo json_encode($compass); ?>;
	compass=parseFloat(compass);
var star=<?php echo json_encode($star); ?>;
	star=parseFloat(star);
var heart=<?php echo json_encode($heart); ?>;
	heart=parseFloat(heart);
var lightning=<?php echo json_encode($lightning); ?>;
	lightning=parseFloat(lightning);
var batman=<?php echo json_encode($batman); ?>;
	batman=parseFloat(batman);

function doPrice(){
if(glass == "pint"){
	//alert(pint);
	pPrice= pint;
}else if (glass =="whiskey"){
	//alert(whiskey);
	pPrice = whiskey;
}else if (glass == "pilsner"){
	//alert(pilsner);
	pPrice=pilsner;
}else if (glass == "snifter"){
	//alert(snifter);
	pPrice = pilsner;
}else if (glass == "shot"){
	//alert(shot);
	pPrice = pilsner;
}
else{ alert(palert);
}

if(cust == "cross"){
	//alert(cross);
	cPrice= cross;
}else if (cust =="compass"){
	//alert(compass);
	cPrice = compass;
}else if (cust == "star"){
	//alert(star);
	cPrice=star;
}else if (cust == "heart"){
	//alert(heart);
	cPrice = heart;
}else if (cust == "lightning"){
	//alert(lightning);
	cPrice = lightning;
}else if (cust == "batman"){
	//alert(batman);
	cPrice = batman;
}

else{ alert(calert);
}

var tPrice= pPrice  +  cPrice;
//alert(tPrice);

ctx.font="20px Arial Black";
ctx.fillText(tPrice,20, 52);
/*
<%Session["total"]= "tPrice" %>;
var total=(<%Session["total"]%>;
alert(total);
*/
}
	</script>


</head>
<body>
	<header>
	</header>
	<nav>
		<ul>		
			<li><a href="Glassware.php">Glassware</a></li>
			<li><a href="BottleOpeners.php">Bottle Openers</a></li>
			<li><a href="BarSupplies.php">Bar Supplies</a></li>
			<li><a href="logout.php">Logout</a></li>

								</ul>
	</nav>
	<aside>
	<?php

//testing to make sure I'm getting an output
/*
echo "Products:";
echo "</br>";
echo $pint;
echo "</br>";
echo $whiskey;
echo "</br>";
echo $pilsner;
echo "</br>";
echo $snifter;
echo "</br>";
echo $shot;
echo "<hr>";	
echo "Customizations:";
echo "</br>";
echo $cross;
echo "</br>";
echo $compass;
echo "</br>";
echo $star;
echo "</br>";
echo $heart;
echo "</br>";
echo $lightning;
echo "</br>";
echo $batman;
echo "</br>";
*/


//Pricing session variable needs to get figured out
//$_SESSION['TPRICE']= tprice;
 
?>

	</aside>
	<section>
		<form id="frm">
			<fieldset>
				<legend>Glass Type</legend>
					<input id="G1" type="button" onclick="doPostG1();" value="Pint"><!--if the input = G1 pull this line then call G1?? take time and think-->
					<input id="G2" type="button" onclick="doPostG2();" value="Whiskey">
					<input id="G3" type="button" onclick="doPostG3();" value="Pilsner">
					<input id="G4" type="button" onclick="doPostG4();" value="Snifter">
					<input id="G5" type="button" onclick="doPostG5();" value="Shot">
					<hr>Customization
					<input id="cus1" type="button" onclick="doPostC1();" value="Cross">
					<input id="cus2" type="button" onclick="doPostC2();" value="Compass">
					<input id="cus3" type="button" onclick="doPostC3();" value="Star">
					<input id="cus4" type="button" onclick="doPostC4();" value="Heart">
					<input id="cus5" type="button" onclick="doPostC5();" value="Lightning">
					<input id="cus6" type="button" onclick="doPostC6();" value="Batman">
					<hr>
					<input id="sub" type="button" onclick="doPrice()" value="Price">
					<input id="res" type="reset" onclick="doReset();" value="Reset">
						
						
				</fieldset>
		
				<fieldset>
					<div id="out">
					<canvas id="canvas" width="300" height="450"></canvas>
											</div>
			</fieldset>	
			<fieldset><legend>Price</legend>
				<div id="price">
				<canvas id="canvas2" width="100" height="100"></canvas>
				</div>
				<hr>
				<input id="checkout" type="button" value="Checkout" onclick="window.location='/CustomDrinkPhP/shipping.php';">
			</fieldset>	
			</form>
		</section>
		
	<footer>
	</footer>
</body>
</html>