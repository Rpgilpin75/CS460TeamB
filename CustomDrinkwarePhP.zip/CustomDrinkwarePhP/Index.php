﻿<html>
<head>
	<meta charset="utf-8">
	<title>Custom Drinkware</title>
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<style type="text/css">
	</style>
	<script type="text/javascript">
	
	</script>
	
</head>

<body>
	<header>
	</header>
	<nav>
			<ul>
			<li><a href="Index.php">Home</a></li>		
			<li><a href="Glassware.php">Glassware</a></li>
			<li><a href="BottleOpeners.php">Bottle Openers</a></li>
			<li><a href="BarSupplies.php">Bar Supplies</a></li>
			<li><a href="Login.php">Login</a></li>
			<li><a href="register.php">Register</a></li>
					</ul>
	</nav>
	<aside>
	
	</aside>
	<section>
		<img src="images/avatar.png">
	</section>
	<footer>
	</footer>
</body>
</html>