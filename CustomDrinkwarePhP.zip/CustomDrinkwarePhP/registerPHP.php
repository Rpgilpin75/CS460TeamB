<html>
<head>
	<meta charset="utf-8">
	<title>Custom Drinkware</title>
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<style type="text/css">
	</style>
	<script type="text/javascript">
		</script>
	
</head>

<body>
<header>
	</header>
	<nav>
		<ul>
			<li><a href="Index.php">Home</a></li>		
			<li><a href="Login.php">Login</a></li>
						</ul>
	</nav>
<aside>
<h3>Thank you for registering. Please login</h3>
</aside>
<section>
<img src="images/avatar.png">
</section>
<?php 
session_start();  //establish session

//get values from form
$id = "DEFAULT";
$first = test_input($_POST["firstname"]);
$last = test_input($_POST["lastname"]);
$un =  test_input($_POST["username"]);
$pass = test_input($_POST["password"]);
$phone = test_input($_POST["phone"]);
$address = test_input($_POST["address"]);
$city = test_input($_POST["city"]);
$state = test_input($_POST["state"]);
$zip = test_input($_POST["zip"]);
$cusun = $un;

      	
///PHP variables to connect to db
$servername = "frodo.bentley.edu";
$username = "cs460teamb";
$password = "mysql";
$dbname ="cs460teamb";

//this is the connection to the database
$conn = mysqli_connect($servername,$username,$password,$dbname);

//Insert the values into the various tables
//customer
$insertcus = "INSERT INTO CUSTOMER(CUSTOMER_ID, CUSTOMER_FIRST_NAME, CUSTOMER_LAST_NAME, CUSTOMER_PHONE_NUMBER, CUSTOMER_STREET_ADDRESS, CUSTOMER_TOWN, CUSTOMER_STATE, CUSTOMER_ZIP, USERNAME) VALUES ('$id','$first','$last','$phone', '$address', '$city', '$state', '$zip', '$cusun')";
	$ciResult =mysqli_query($conn, $insertcus) or die(header("location: register.php"));

$query = "SELECT * FROM Login WHERE Username='$un'";
$result = mysqli_query($conn, $query) or die('Query failed: ' . mysqli_errno($conn));
$rows = mysqli_num_rows($result);//no rows = no access

//if userid is in login table, go to register page and try again
if ($rows > 1) header("Location: register.php");
		

//login
$insertlog = "INSERT INTO LOGIN (USERNAME, PASS) VALUES ('$un','$pass')";
	$liResult =mysqli_query($conn, $insertlog) or die(header("location: register.php") /*echo("<script type='text/javascript'>alert(The username you entered is already taken);</script>")*/);

//}
/*
//$cresult = "SELECT * from CUSTOMER";

//print contents of customer table to webpage, useful when debugging
echo "<table>\n";
//loop over result set. Print a table row for each record
while ($line = mysqli_fetch_array($cresult, MYSQL_ASSOC)) {
    echo "\t<tr>\n";
    //inner loop. Print each table field value for a record
    foreach ($line as $col_value) {
        echo "\t\t<td>$col_value</td>\n";
    }
    echo "\t</tr>\n";
}
echo "</table>\n";

$lresult = "SELECT * from LOGIN";

//print contents of customer table to webpage, useful when debugging
echo "<table>\n";
//loop over result set. Print a table row for each record
while ($linel = mysqli_fetch_array($lresult, MYSQL_ASSOC)) {
    echo "\t<tr>\n";
    //inner loop. Print each table field value for a record
    foreach ($linel as $col_value) {
        echo "\t\t<td>$col_value</td>\n";
    }
    echo "\t</tr>\n";
}
echo "</table>\n";

//get login table record for userid
*/
// Free resultset
//mysqli_free_result($result);


// Close connection
mysqli_close($conn);


 
function test_input($data){
     $data = trim($data);
     $data = stripslashes($data);
     $data = htmlspecialchars($data);
     return $data;
}

?>

</body>

</html>
