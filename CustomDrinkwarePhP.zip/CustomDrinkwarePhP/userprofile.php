<html>
<head>
	<meta charset="utf-8">
	<title>Custom Drinkware</title>
	<link href="images/avatar.png" rel="shortcut icon" type="image/png">
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<style type="text/css">
	section{
	color:black;
}
	aside{
	width:50px;
}
h1{
	text-align:center;
}
	</style>
		
</head>

<body>
<header>
	</header>
	<nav>
		<ul>
			<ul>		
			<li><a href="Glassware.php">Glassware</a></li>
			<li><a href="BottleOpeners.php">Bottle Openers</a></li>
			<li><a href="BarSupplies.php">Bar Supplies</a></li>
			<li><a href="userprofile.php">Profile</a></li>
			<li><a href="logout.php">Logout</a></li>

								</ul>
						</ul>
	</nav>

<aside>
</aside>
<section>
<?php 
session_start();  //establish session

$cusid=$_SESSION['customer'];
      	
///PHP variables to connect to db
$servername = "frodo.bentley.edu";
$username = "cs460teamb";
$password = "mysql";
$dbname ="cs460teamb";

//this is the connection to the database
$conn = mysqli_connect($servername,$username,$password,$dbname);

$profile= array();
$orders= array();

$query = "SELECT * FROM customer WHERE CUSTOMER_ID='$cusid'";
$result = mysqli_query($conn, $query) or die('Query failed: ' . mysqli_errno($conn));
$rows = mysqli_num_rows($result);//no rows = no access
echo("<h1> Your Information </h1>");

if (mysqli_num_rows($result) > 0) {
echo("<div  style='text-align:center'>");
// output data of each row so that we can see it
    while($row = mysqli_fetch_assoc($result)) {
       echo "<br>"."<b>" ."Name: "."</b>" . $row["CUSTOMER_FIRST_NAME"]. " ". $row["CUSTOMER_LAST_NAME"]. "<br>"."<b>"."Phone Number: "."</b>" . $row["CUSTOMER_PHONE_NUMBER"]. "<br>"."<b>"."Address: " ."</b>" .$row["CUSTOMER_STREET_ADDRESS"]. ", ". $row["CUSTOMER_TOWN"]." ". $row["CUSTOMER_STATE"]. ", ". $row["CUSTOMER_ZIP"]. "<br>"."<b>" ."Username: "."</b>" .$row["USERNAME"];
           }
} else {
    echo "0 results";
}
echo("</div>");
echo("<div style ='text-align:center'>");
echo("<img src='images/glassware.png' align='middle'>");	
echo("</div>");
$orderselect = "SELECT * from ORDERS where CUSTOMER_ID='$cusid'";
$results= mysqli_query($conn, $orderselect) or die('Query failed: ' . mysqli_errno($conn));
/*if (mysqli_num_rows($result) > 0) {
// output data of each row so that we can see it
    while($rows = mysqli_fetch_assoc($results)) {
       echo "<br>". "Product: " . $row["PRODUCT_NAME"]. "<br>". "Customization:  ".$row["CUSTOMIZATION_NAME"]. "<br>". "Date Ordered: " . $row["DATE_ORDERED"]. "<br>"."Order Total: " . $row["ORDER_TOTAL"];
           }
} else {
    echo "0 results";
}

*/
//print contents of customer table to webpage, useful when debugging
echo("<h1> Your Customizations</h1>");
echo ("<table align='center' class='solid'>\n");
while ($i = mysqli_fetch_field($results))  echo"<th> $i->name </th>";
echo "  </tr>";

//print data
while ($line = mysqli_fetch_array($results, MYSQL_ASSOC)) {
    echo "\t<tr>\n";
    foreach ($line as $col_value) {
        echo "\t\t<td width='100'>$col_value</td>\n";
    }
    echo "\t</tr>\n";
    
    
  }
  echo "</table>";
//get login table record for userid

// Free resultset
//mysqli_free_result($result);


// Close connection
mysqli_close($conn);


 
function test_input($data){
     $data = trim($data);
     $data = stripslashes($data);
     $data = htmlspecialchars($data);
     return $data;
}

?>


</section>
<footer>
</footer>
</body>
</html>
