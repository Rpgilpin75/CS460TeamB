﻿<html>
<head>
	<meta charset="utf-8">
	<title>Custom Drinkware</title>
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<script src="js/glassbuttons.js" type="text/javascript"></script>
	<script src="js/bottleopeners.js" type="text/javascript"></script>
	<script src="js/barbuttons.js" type="text/javascript"></script>
	<script src="js/customize.js" type="text/javascript"></script>
	<style type="text/css">
	fieldset {
	margin: .1in 0in .1in .25in;
	float: left;
	border-radius: 12px;
}
	input, select {
	display: block;
}
	input[type=text] {
	width: 170px;
}
	input[type=button], input[type=reset] {
	display: block;
	clear: left;
	width: .75in;
	margin: .05in;
}
	#out {
	text-align: center;
}
	#out span {
	display: block;
	font-size: 18pt;
	width: 600px;
}
	hr {
	clear: left;

}	
</style>

	<script type="text/javascript">
	
	</script>
</head>
<body>
	<header>
	</header>
	<nav>
		<ul>
			<li><a href="index.php">Home</a></li>						
					</ul>
	</nav>
	<aside>
	
	</aside>
	<section>
<fieldset>
<h1 style="text-align:left">Custom Drinkers Sign In</h1>
<form action="checklog.php" method="post">
<table align="justify">
<tr><td>Username:</td><td> <input type="text" name="name"></td></tr><br/>
<tr><td>Password:</td><td> <input type="password" name="password"></td></tr><br/>
<tr><td colspan="2"><input type="submit" value="Submit"></td></tr>
</table>
</form>
</fieldset>

</section>
	<footer>
	</footer>
</body>
</html>