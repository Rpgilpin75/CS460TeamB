<html>
<head>
	<meta charset="utf-8">
	<title>Custom Drinkware</title>
	<link href="images/avatar.png" rel="shortcut icon" type="image/png">
	<link href="css/stylesheet.css" rel="stylesheet" type="text/css">
	<link href="css/Core.css" rel="stylesheet" type="text/css">
	<script src="js/javascript.js" type="text/javascript"></script>
	<script src="js/glassbuttons.js" type="text/javascript"></script>
	<script src="js/bottleopeners.js" type="text/javascript"></script>
	<script src="js/barbuttons.js" type="text/javascript"></script>
	<script src="js/customize.js" type="text/javascript"></script>
	<style type="text/css">
	fieldset {
	margin: .1in 0in .1in .25in;
	float: left;
	border-radius: 12px;
}
	input, select {
	display: block;
}
	input[type=text] {
	width: 170px;
}
	input[type=button], input[type=reset] {
	display: block;
	clear: left;
	width: .75in;
	margin: .05in;
}
	#out {
	text-align: center;
}
	#out span {
	display: block;
	font-size: 18pt;
	width: 600px;
}
	hr {
	clear: left;

}	
</style>
	<script type="text/javascript">
			</script>
	
</head>

<body>
<header>
	</header>
	<nav>
		<ul>
			<li><a href="Glassware.php">Glassware</a></li>
			<li><a href="BottleOpeners.php">Bottle Openers</a></li>
			<li><a href="BarSupplies.php">Bar Supplies</a></li>
			<li><a href="userprofile.php">Profile</a></li>
			<li><a href="logout.php">Logout</a></li>

									</ul>
	</nav>
<aside>
<h1>Thank you for your order</h1>
</aside>
<section>
<?php 
session_start();  //establish session
//get values from form
$cusid=$_SESSION['customer'];
$shipid=$_SESSION['shippingid'];
$payid=$_SESSION['payid'];
$orderid="DEFAULT";
$tprice=$_SESSION['totalprice'];
//$tprice=parseFloat($tprice);
$prodname=$_SESSION['productname'];
$custname=$_SESSION['customname'];
$dateord=$_SESSION['today'];
/*
echo($cusid);
echo("<br>");
echo($shipid);
echo("<br>");
echo($payid);
echo("<br>");
echo($dateord);
echo("<br>");
echo($tprice);
echo("<br>");
echo($prodname);
echo("<br>");
echo($custname);
*/
 	
///PHP variables to connect to db
$servername = "frodo.bentley.edu";
$username = "cs460teamb";
$password = "mysql";
$dbname ="cs460teamb";

//this is the connection to the database
$conn = mysqli_connect($servername,$username,$password,$dbname);

//Insert the values into the various tables
//order
$insertorder = "INSERT INTO ORDERS(ORDER_ID, CUSTOMER_ID, DATE_ORDERED, SHIPPING_ID, PAYMENT_ID, ORDER_TOTAL, PRODUCT_NAME, CUSTOMIZATION_NAME) VALUES ('$orderid', '$cusid', '$dateord', '$shipid', '$payid', '$tprice','$prodname','$custname')";
	$ioResult =mysqli_query($conn, $insertorder) or die('Insert Failed for order: ' . mysqli_errno($conn));

//}
/*
//$cresult = "SELECT * from CUSTOMER";

//print contents of customer table to webpage, useful when debugging
echo "<table>\n";
//loop over result set. Print a table row for each record
while ($line = mysqli_fetch_array($cresult, MYSQL_ASSOC)) {
    echo "\t<tr>\n";
    //inner loop. Print each table field value for a record
    foreach ($line as $col_value) {
        echo "\t\t<td>$col_value</td>\n";
    }
    echo "\t</tr>\n";
}
echo "</table>\n";

$lresult = "SELECT * from LOGIN";

//print contents of customer table to webpage, useful when debugging
echo "<table>\n";
//loop over result set. Print a table row for each record
while ($linel = mysqli_fetch_array($lresult, MYSQL_ASSOC)) {
    echo "\t<tr>\n";
    //inner loop. Print each table field value for a record
    foreach ($linel as $col_value) {
        echo "\t\t<td>$col_value</td>\n";
    }
    echo "\t</tr>\n";
}
echo "</table>\n";

//get login table record for userid
*/
// Free resultset
//mysqli_free_result($result);


// Close connection
mysqli_close($conn);


 
function test_input($data){
     $data = trim($data);
     $data = stripslashes($data);
     $data = htmlspecialchars($data);
     return $data;
}
?>

<p style='text-align:center;'><img src='images/avatar.png'/>
</section>
<footer>
</footer>
</body>

</html>
