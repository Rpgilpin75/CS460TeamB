﻿function doNow(){ //onload function to initialize calendar

	//get today's date and break into variables
	var today = new Date();
	var d = today.getDate();
	var m = today.getMonth() + 1;
	var y = today.getFullYear();
	//put today's date values into form
	document.getElementById("day").value = d;
	document.getElementById("month").value = m;
	document.getElementById("year").value = y;
	document.getElementById("annotation").value = "Today's date!";
	//create calendar image with today's date
	doThings();
 }

function doThings() {
	//Set all the objects in the calendar to the values determined by the form input by calling a bunch of small functions
	setDayNumber();
	setDayText();
	setMonthText();
	setYearNum();
	setDayOfYear();
	setJulianNum();
	setAnnotation();
	}
			
function setMonthText() { //sets month string to the correct string based on input value
	var months = ['none', 'January','February','March','April','May','June','July', 'August', 'September', 'October', 'November', 'December'];
	var m = document.getElementById("month").value;
	document.getElementById("monthText").innerHTML = months[m];
	}
function setYearNum(){ //sets the year to the input year
	var m = document.getElementById("year").value;
	document.getElementById("yearNum").innerHTML = m;
	}

function setDayNumber () {
	document.getElementById("dayNum").innerHTML = document.getElementById("day").value; //set day number to input day
	} 
	

function setDayText() { //dtermine day of week of input value
	//arrays to store days and months
	var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']; //array with day names
	var months = ['none', 'January','February','March','April','May','June','July', 'August', 'September', 'October', 'November', 'December'];
	
	//retrieve inputs
	var d = document.getElementById("day").value;
	var m = document.getElementById("month").value;
	var y = document.getElementById("year").value;
	
	//create a Date object from inputs
	var month = months[m]
	var dateString = (month + " " + d + ", " + y);
	var date = new Date(dateString);
	
	//get the day of week using getDay() method and output it as a string 
	var dow = date.getDay();
	document.getElementById("dayText").innerHTML = days[dow];
}

function setDayOfYear() {
		var i = parseInt(document.getElementById("year").value);
		var j = parseInt(document.getElementById("month").value);
		var k = parseInt(document.getElementById("day").value);
		var a = Math.floor(30.55 * (j + 2) - 91);
		var b = leapYear(i);
		if(j > 2) a = a - 2 + b;
		var n = a + k;
		
		//check if leap year to determine number of days remaining in year
		if (leapYear(i) === 1) {
			var dl = 366 - n;
			}
			else
			{
			var dl = 365  - n;
			}
		document.getElementById("doy").innerHTML = n+"/ "+dl; //set day of year and days left string
	}

function leapYear(i) {
		var n = 0;
		if(i % 4 == 0) n = 1;
		if(i % 100 == 0) n = 0;
		if(i % 400 == 0) n = 1;
		return n;
	}

function setJulianNum() {
		var i = parseInt(document.getElementById("year").value);
		var j = parseInt(document.getElementById("month").value);
		var k = parseInt(document.getElementById("day").value);
		if (j > 2) {
			m = j - 3;
			y = i;
		}
		else {
			m = j + 9;
			y = i - 1;
		}
		var c = Math.floor(y / 100);
		var d = y % 100;
		var p = Math.floor((146097 * c)/4);
		var q = Math.floor((1461 * d)/4);
		var r = Math.floor((153 * m + 2)/5);
		var n = p + k + q + 1721119 + r;
		document.getElementById("julian").innerHTML = n; //set julian number to calculation output
}
	
function setAnnotation(){ //set annotation to value in form
	var a = document.getElementById("annotation").value;
	document.getElementById("ann").innerHTML = a;
	
}

function doReset(){ //set all objects to blank
	document.getElementById("dayText").innerHTML = "";
	document.getElementById("dayNum").innerHTML = "";
	document.getElementById("annotation").value = "";
	document.getElementById("ann").innerHTML = "";
	document.getElementById("monthText").innerHTML = "";
	document.getElementById("yearNum").innerHTML = "";
	document.getElementById("julian").innerHTML = "";
	document.getElementById("doy").innerHTML = "";
}


