﻿                function dayOfWeek(j,k,i) {
                                                var a = Math.floor((14 - j) / 12);
                                                var y = i - a;
                                                var m = j + 12 * a - 2;
                                                var n = (k + y + Math.floor(y / 4) - Math.floor(y / 100) + Math.floor(y / 400) + Math.floor((31 * m) / 12)) % 7;
                                                return n;
                                }
                                
                                function dayOfWeekName(dow) {
                                                var name = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                                                return name[dow];
                                }
                                
                                function monthName(mon) {
                                	var name = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                                	return name[mon-1];
                                }
                                
                                function julianDate(j,k,i) {
                                                                if (j > 2) {
                                                                                m = j - 3;
                                                                                y = i;
                                                }
                                                else {
                                                                m = j + 9;
                                                                y = i - 1;
                                                }
                                                var c = Math.floor(y / 100);
                                                var d = y % 100;
                                                var p = Math.floor((146097 * c)/4);
                                                var q = Math.floor((1461 * d)/4);
                                                var r = Math.floor((153 * m + 2)/5);
                                                var n = p + k + q + 1721119 + r;
                                                return n;
                                }
                                
                                function leapYear(i) {
                                                var n = 0;
                                                if(i % 4 == 0) n = 1;
                                                if(i % 100 == 0) n = 0;
                                                if(i % 400 == 0) n = 1;
                                                return n;
                }

                                function daysInMonth(j,i) {
                                                var n;
                                                switch (j) {
                                                                case 1:
                                                                case 3:
                                                                case 5:
                                                                case 7:
                                                                case 8:
                                                                case 10:
                                                                case 12:
                                                                                n = 31;
                                                                                break;
                                                                case 4:
                                                                case 6:
                                                                case 9:
                                                                case 11:
                                                                                n = 30;
                                                                                break;
                                                                case 2:
                                                                                n = 28 + leapYear(i);
                                                                                break;                   
                                                }
                                                return n;
                                }              
                                
                                function dayOfYear(j,k,i) {
                                                var a = Math.floor(30.55 * (j + 2) - 91);
                                                var b = leapYear(i);
                                                if(j > 2) a = a - 2 + b;
                                                var n = a + k;
                                                return n;
                                }
                