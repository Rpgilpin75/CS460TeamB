﻿function setup() {
	var select = document.getElementById("cards"); 
	var suits = ["Spades", "Diamonds", "Clubs", "Hearts"];
	var numbers = ["Ace", "King", "Queen", "Jack", "Ten", "Nine", "Eight", "Seven", "Six", "Five", "Four", "Three", "Two"];
	var CANVAS;
	var CONTEXT;
	
	for(var i = 0; i < suits.length; i++) {
		for(var k = 0; k < numbers.length; k++){
		    var opt = numbers[k] + " of " + suits[i];
		    var el = document.createElement("option");
		    el.textContent = opt;
		    el.innerHTML = opt;
		    el.value = numbers[k]+","+suits[i];
		    select.appendChild(el);
		}
	}
}

function cardFront() {

	var selection = document.getElementById('cards').value;
	var comma = selection.indexOf(',');
	var card = selection.substring(0, comma).toLowerCase();
	var suit = selection.substring(comma+1, selection.length).toLowerCase();
	
	
	switch(card) {
		case 'ace':
			document.getElementById('number').innerHTML = "A";
			break;
		case 'king':
			document.getElementById('number').innerHTML = 'K';
			break;
		case 'queen':
			document.getElementById('number').innerHTML = 'Q';
			break;
		case 'jack':
			document.getElementById('number').innerHTML = 'J';
			break;
		case 'ten':
			document.getElementById('number').innerHTML = '10';
			break;
		case 'nine':
			document.getElementById('number').innerHTML = '9';
			break;
		case 'eight':
			document.getElementById('number').innerHTML = '8';
			break;
		case 'seven':
			document.getElementById('number').innerHTML = '7';
			break;
		case 'six':
			document.getElementById('number').innerHTML = '6';
			break;
		case 'five':
			document.getElementById('number').innerHTML = '5';
			break;
		case 'four':
			document.getElementById('number').innerHTML = '4';
			break;
		case 'three':
			document.getElementById('number').innerHTML = '3';
			break;
		case 'two':
			document.getElementById('number').innerHTML = '2';
			break;
		}	
		switch(suit){
		case 'spades':
			document.getElementById('image').src = "images/spades.png";
			document.getElementById('number').style.color = 'black';
			break;
		case 'hearts':
			document.getElementById('image').src = "images/heart.png";
			document.getElementById('number').style.color = '#D52027';
			break;
		case 'clubs':
			document.getElementById('image').src = "images/club.png";
			document.getElementById('number').style.color = 'black';
			break;
		case 'diamonds':
			document.getElementById('image').src = "images/diamonds.png";
			document.getElementById('number').style.color = '#D52027';
			break;
	}
}

