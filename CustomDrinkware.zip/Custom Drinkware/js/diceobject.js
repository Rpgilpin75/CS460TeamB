﻿function Dice(sides,color) {
		if(!sides) sides = [1,2,3,4,5,6];
		this.sides = sides;
		this.color = color;
		this.toss = function() {
		return sides[Math.floor(6 * Math.random())];
		}
	}
	
function PairOfDice(kind, color){
		switch(kind){
		case "0":
			this.kind = "Regular";
			this.first = [1,2,3,4,5,6];
			this.second = [1,2,3,4,5,6];
			break;
		case "1":
			this.kind = "Sicherman";
			this.first = [1,2,2,3,3,4];
			this.second = [1,3,4,5,6,8];
			break;
		case "2":
			this.kind = "Alligator";
			this.first = [1, "alligator", 3, 4, 5, 6];
			this.second = [1, 2, 3, 4, "alligator", 6];
			break;
		}
		this.color = color; 
		this.toss = function(){
			var d1 = new Dice(this.first, this.color);
			this.die1 = d1.toss();
			var d2 = new Dice(this.second, this.color);
			this.die2 = d2.toss();
			var d3 = new Dice(this.third, this.color);
			this.die3 = d3.toss();
			var d4 = new Dice(this.fourth, this.color);
			this.die4 = d4.toss();
			var d5 = new Dice(this.fifth, this.color);
			this.die5 = d5.toss();

		}
		this.sum = function(){
			return this.die1 + this.die2;
		}
		this.doubles = function(){
			return this.die1 == this.die2;
		}
	}