﻿function regularDie() {
	return fnr(1,6);
}

 
function sichermanDie1(){
 	var sd1=[1,2,2,3,3,4];
 	return sd1[fnr(0,5)];
 }
 
 function sichermanDie2(){
 	var sd2=[1,3,4,5,6,8];
 	return sd2[fnr(0,5)];
 }	